from flask import Flask, render_template,request
import sqlite3
import timeit
import os
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import style
 
app = Flask(__name__)
port = int(os.getenv('PORT', 8000))

@app.route("/")
def hello():
    return render_template('home.html')

@app.route('/query2',methods=['GET','POST'])
def query2():
	if(request.method=='POST'):
		con=sqlite3.connect('all_months.db')
		cur=con.cursor()
		mg1=float(request.form['mag1'])
		mg2=float(request.form['mag2'])
		cur.execute('''SELECT latitude, longitude, mag > ? and mag < ? from all_months''',(mg1,mg2))
		data=cur.fetchall()

		lat=[]
		lon=[]

		for row in data:
			lat.append(row[0])
			lon.append(row[1])

		plt.plot(lat,lon,'.')
		plt.show()
	return render_template('query2.html')


@app.route('/magpiechart',methods=['GET','POST'])
def magpiechart():
	con=sqlite3.connect('all_months.db')
	cur=con.cursor()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 1 AND 4''')
	mag1= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 2 AND 6''')
	mag2= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 5 AND 8''')
	mag3= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 3 AND 4''')
	mag4= cur.fetchone()
	
	countList = [mag1[0],mag2[0],mag3[0],mag4[0]]
	print(countList)
	return render_template('magpiechart.html', countList=countList)


@app.route('/magbargraph',methods=['GET','POST'])
def magbargraph():
	con=sqlite3.connect('all_months.db')
	cur=con.cursor()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 1 AND 4''')
	mag1= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 2 AND 6''')
	mag2= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 5 AND 8''')
	mag3= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 3 AND 4''')
	mag4= cur.fetchone()
	
	countList = [mag1[0],mag2[0],mag3[0],mag4[0]]
	print(countList)
	return render_template('magbargraph.html', countList=countList)

@app.route('/magcolumnchart',methods=['GET','POST'])
def magcolumnchart():
	con=sqlite3.connect('all_months.db')
	cur=con.cursor()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 1 AND 4''')
	mag1= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 2 AND 6''')
	mag2= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 5 AND 8''')
	mag3= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 3 AND 4''')
	mag4= cur.fetchone()
	
	countList = [mag1[0],mag2[0],mag3[0],mag4[0]]
	print(countList)
	return render_template('magcolumnchart.html', countList=countList)

@app.route('/scatterchart',methods=['GET','POST'])
def scatterchart():
	con=sqlite3.connect('all_months.db')
	cur=con.cursor()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 1 AND 4''')
	mag1= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 2 AND 6''')
	mag2= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 5 AND 8''')
	mag3= cur.fetchone()
	cur.execute('''SELECT count(mag) from all_months WHERE mag BETWEEN 3 AND 4''')
	mag4= cur.fetchone()
	
	countList = [mag1[0],mag2[0],mag3[0],mag4[0]]
	print(countList)
	return render_template('scatterchart.html', countList=countList)




if __name__ == '__main__':
    app.run()
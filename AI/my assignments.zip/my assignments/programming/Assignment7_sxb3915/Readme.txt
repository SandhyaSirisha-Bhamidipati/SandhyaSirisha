Name : Sandhya Sirisha Bhamidipati

UTA ID: 1001663914

Language : Python

Code Structure:
There are 2 python files within this program: check_true_false.py and logical_expression.py

check_true_false.py contains all the required functions to execute the wumpus world rules, additional knowledge and statement files as input and call the required function.

logical_expression.py has the function implementation of the AI algorithms and check functions.


Syntax:
Sample command to be run on command line.
python check_true_false.py [wumpus-rules-file] [additional-knowledge-file] [input_file] 
import sys
from copy import *
from BayesianNodes import *


def genTT(TT,input_rules):
    if input_rules.count(None) != 0:
        blank = input_rules.index(None)
        t = deepcopy(input_rules)
        t[blank] = True
        f = deepcopy(input_rules)
        f[blank] = False
        genTT(TT,t)
        genTT(TT,f)
        return TT
    else:
        TT.append(input_rules)
        return TT


def main(argv):

    statement = argv[1:]
    condition = [];
    burglary = 0.0;
    earthquake = 0.0;
    alarm = 0.0;
    JohnCalls = 0.0;
    MaryCalls = 0.0;
    count_b=0.0;
    full_statement=None;
    out_string=str(argv[1:])
    for inputField in statement:

        first = inputField[0].upper();
        second = inputField[1];
        if first == 'B' and second == 't':
            burglary = True
            full_statement="(Burglary=true)";
            out_string.replace("Bt", "Burglary=true")

        elif first == 'B' and second == 'f':
            burglary = False
            full_statement="(Burglary=true)";
            out_string.replace("Bf", "Burglary=false")

        if first == 'E' and second == 't':
            earthquake = True
            out_string.replace("Et", "earthquake=true")

        elif first == 'E' and second == 'f':
            earthquake = False
            full_statement="(earthquake=false)";
            out_string.replace("Ef", "earthquake=false")

        if first == 'A' and second == 't':
            alarm = True
            full_statement="(Alarm=true)";
            out_string.replace("At", "Alarm=true")

        elif first == 'A' and second == 'f':
            alarm = False
            full_statement="(Alarm=false)";
            out_string.replace("Af", "Alarm=false")

        if first == 'J' and second == 't':
            JohnCalls = True
            full_statement="(JohnCalls=true)";
            out_string.replace("Jt", "JohnCalls=true")

        elif first == 'J' and second == 'f':
            JohnCalls = False
            full_statement="(JohnCalls=false)";
            out_string.replace("Jf", "JohnCalls=false")


        if first == 'M' and second == 't':
            MaryCalls = True
            full_statement="(MaryCalls=true)";
            out_string.replace("Mt", "MaryCalls=true")

        elif first == 'M' and second == 'f':
            MaryCalls = False
            full_statement="(MaryCalls=false)";
            out_string.replace("Mf", "MaryCalls=false")

    givenIndex = 0
    if statement.count('given'):
        givenIndex = statement.index('given')
        for j in range(givenIndex+1,len(statement)):
            condition.append(statement[j][0])
    input_rules = [burglary,earthquake,alarm,JohnCalls,MaryCalls];
    PMT = condition;

    bn = BayesianNodes()
    tables = genTT([],input_rules)

    probability = 0.000

    for values in tables:
        probability += bn.computeProbability(values[0],values[1],values[2],values[3],values[4],condition)

    print 'P('+out_string+') is '+str('%.9f'%probability)

if __name__ == '__main__':
    main(sys.argv)
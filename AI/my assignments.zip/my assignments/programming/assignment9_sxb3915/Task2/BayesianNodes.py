from decimal import *

class BayesianNodes:
    BNP = {}
    B = 0.001
    E = 0.002
    BNP['MT'] = {'AT':0.70,'AF':0.01}
    BNP['JT'] = {'AT':0.90,'AF':0.05}
    BNP['AT'] = {'BT_ET':0.95,'BT_EF':0.94,'BF_ET':0.29,'BF_EF':0.001}


    def computeProbability(self, burglary, earthquake, alarm, John, Mary, conditions):
        JohnCalls = 0.00
        MaryCalls = 0.00
        Alarm_p = 0.00
        probability = 1
        p_burglary = 0.00
        p_earthquake = 0.00
        PMT = 1.00

        if earthquake:
            p_earthquake = self.E
        else:
            p_earthquake = 1 - self.E

        if burglary:
            p_burglary = self.B
        else:
            p_burglary = 1 - self.B

        if alarm:
            if John:
                JohnCalls = self.BNP['JT']['AT']
            else:
                JohnCalls = 1 - self.BNP['JT']['AT']
            if Mary:
                MaryCalls = self.BNP['MT']['AT']
            else:
                MaryCalls = 1 - self.BNP['MT']['AT']
        else:
            if John:
                JohnCalls = self.BNP['JT']['AF']
            else:
                JohnCalls = 1 - self.BNP['JT']['AF']
            if Mary:
                MaryCalls = self.BNP['MT']['AF']
            else:
                MaryCalls = 1 - self.BNP['MT']['AF']

        if burglary and earthquake:
            if alarm:
                Alarm_p = self.BNP['AT']['BT_ET']
            else:
                Alarm_p = 1 - self.BNP['AT']['BT_ET']
        if (not burglary) and earthquake:
            if alarm:
                Alarm_p = self.BNP['AT']['BF_ET']
            else:
                Alarm_p = 1 - self.BNP['AT']['BF_ET']
        if burglary and (not earthquake):
            if alarm:
                Alarm_p = self.BNP['AT']['BT_EF']
            else:
                Alarm_p = 1 - self.BNP['AT']['BT_EF']
        if (not burglary) and (not earthquake):
            if alarm:
                Alarm_p = self.BNP['AT']['BF_EF']
            else:
                Alarm_p = 1 - self.BNP['AT']['BF_EF']

        for condition1 in conditions:
            if condition1 == 'B':
                PMT*=p_burglary
            if condition1 == 'E':
                PMT*=p_earthquake
            if condition1 == 'A':
                PMT*=Alarm_p
            if condition1 == 'J':
                PMT*=JohnCalls
            if condition1 == 'M':
                PMT*=MaryCalls

        num = (JohnCalls*MaryCalls*Alarm_p*p_burglary*p_earthquake)
        return num/PMT
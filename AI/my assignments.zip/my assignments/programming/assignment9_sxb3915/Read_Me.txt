Name : Sandhya Sirisha Bhamidipati
UTA ID: 1001663914


Task 1:
Programming language used: Java

Code Structure:
The program has been structured within 2 files., compute_a_posteriori.java and hypothesis.java

The JAVA file 'compute_a_posteriori.java' has all the functions which calculate the posteriori logic and generate the result file.

The JAVA file 'hypothesis.java' has the class with all the variables representing the problems mentioned for the hypothesis.

Syntax:

javac compute_a_posteriori.java
java compute_a_posteriori <Observation>

e.g., java compute_a_posteriori CCLCCLCCL




Task 2:
Programming language used: Python

Code Structure:
The program has been structured within 2 files., BayesianNodes.py and bnet.py

Python file 'BayesianNodes.py' contains the functions to accept the inputs, process them and pass the arguments to compute the probability.

Python file 'bnet.py' contains the logic to compute the probability.

Syntax:

python bnet.py <Input>

e.g., python bnet.py Bt Af Mf Jt Et